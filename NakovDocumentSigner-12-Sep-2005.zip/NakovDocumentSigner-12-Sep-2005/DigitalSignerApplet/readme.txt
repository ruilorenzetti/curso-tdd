To generate self-signed certificate for signing the applet, run generate-certificate.bat.

To build the applet, run build-script.bat. Be sure to stop the Web browser (all its windows)
and Java Plug-in before. Otherwise the file DigitalSignerApplet.jar will be locked and will
not be replaced (access denied).

To get a free e-mail certificate (PFX keystore with certificate, certificate chain and private
key) for test purposes, go to:

http://www.thawte.com/html/COMMUNITY/personal/index.html

Alternatively to get a free demo certificate go to:

http://www.verisign.com/client/enrollment/index.html
or 
http://secure.globalsign.net/


After installing the certificate, export it from your browser as .PFX (or .P12) file.
