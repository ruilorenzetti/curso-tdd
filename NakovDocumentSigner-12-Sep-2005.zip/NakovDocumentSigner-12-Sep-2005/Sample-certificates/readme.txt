These certificate keystore files are for test purposes only.

The password for all these files is:

parola1

To get your own certificate, please visit some of these CA sites:

Thawte - http://www.thawte.com/html/COMMUNITY/personal/index.html - Free Email certificates
VeriSign - http://www.verisign.com/client/enrollment/index.html - 60 days Demo certificates
GlobalSign - http://secure.globalsign.net/ - 30 days PersonalSign Demo certificates

After your certificate is issued and installed in your browser, export it in .PFX (.P12)
keystore file.
